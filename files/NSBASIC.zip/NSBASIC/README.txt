This is Nathan Stoddard's BASIC interpreter. It's probably not useful for
serious projects; it was intended as a way for me to learn how to implement
an interpreter.

Compiling the interpreter (only necessary if bin/BASIC.exe is not present):
  You need to install the Haskell platform and GLFW. Then, open a command
  line, cd to the source directory, and type:
    ghc --make BASIC -o bin/BASIC -O2

Files:
  bin/ contains the executable and several example programs (some of the
    programs don't work anymore because I recently changed the array
    syntax from array(index) to array[index]
  test/ contains some older and less complete programs
  BASIC.hs, Graphics.hs, and Parse.hs are the source code for the
    interpreter.
  README.txt is this file


Any editor (Notepad, GVim, etc) can be used to edit .bas files. The
interpreter doesn't have a built-in editor. Some editors (such as GVIM)
have syntax highlighting, but it isn't entirely accurate for this dialect
of BASIC.

Most statements can be directly entered into the interpreter's REPL
(read, eval, print loop). Examples:
  > 5+4*3
  17
  > input "What is x? " x
  What is x? 5
  > x^2
  25
  > run hanoi
  (hanoi.bas runs)

Several keywords allow you to create global variables. They should be
used for all variables that can be accessed by multiple functions.
If a variable is declared inside a function without being declared
global, it will be inaccessible outside the function. When a global
variable and a local varible have the same name, the local variable
will be accessed instead of the global one.

Almost everything is case insensitive. These are equivalent:
  closewindow()
  closeWindow()
  CLOSEWINDOW()
However, strings are case sensitive.

When a key is pressed when a graphical window is open, the function
handlekey is called. It takes the key as an argument. If the key is a
letter, it will be upper case. The escape key is "ESC". The enter key
is "\n". The backspace key is "BACKSPACE". See hanoi.bas for an example.

Syntax:
  Strings are enclosed in "double quotes". They can contain these escape
  characters:
    \n - a newline
    \t - a tab
    \\ - a literal '\' character
    \0 - the null character
    \b -> backspace
    \r -> carriage return
    \" -> double quote
    \' -> single quote
  All numbers are floating-point. Examples of valid numbers:
    1
    0.5
    .5
    3.14159
  Arrays:
    Arrays can be accessed like this:
      array[index]
    There is no "dim" statement. Arrays are automatically resized. There
    are no multidimensional arrays.
  Identifiers:
    Used for variable names. The first character can be a letter or
    underscore. The rest of the characters can be letters, underscores,
    digits, or the dollar sign. (I allow the dollar sign because it is
    commonly used to denote string-containing variables in BASIC programs.)
  Labels:
    An identifier followed by a colon. Used with the goto statement.
  Line breaks:
    The : character can be used as a substitute for a newline in order
    to combine multiple statements on one line.

Keywords:
  print <values>
    Prints each of the values on the command line. Commas put tabs
    between values. Semicolons put no space between values. Unless there
    is a semicolon at the end of the line, a newline will be printed.
    Strings are printed without quotes around them.
  ? <values>
    A shortcut for print.
  printdebug <values>
    Prints the values without evaluating them. Useful for debugging.
  input msg var
  input var
    Read input from the user, with an optional message.
  inputglobal
    Like input, but puts the result in a global variable rather than a
    local one.
  goto label
    Jumps to a label.
  run file
    Runs a BASIC file.
  if, then, else, end if
    If statements. The "else" clause is optional. The "else" clause, if it
    exists, must usually be on a separate line. The "end if" statement
    is required only if the THEN clause or ELSE clause are more than one
    line.
    Examples:
      if 1>0 then print "1>0"
        else print "1<=0"

      if _drawRings then
        moveRing(src,dest)
        drawRings()
      else
        print "Move disk from " src " to " dest
      end if
  let var = val
    Assignment. The "let" is optional.
  global var = val
    Like "let", but sets a global variable.
  ' (single quote)
    A single quote starts a comment. It can appear anywhere on a line
    (except inside a string).
  for, to, step, next
    For loops. The "step" clause is optional.
    Examples:
      for i = 0 to 100 step 2
        print i
      next
  do, loop, while, until
    Loops. Several forms are allowed:
      Infinite loop:
        do
          print "test"
        loop
      While:
        while 1>0
          print "test"
        loop
      Until:
        until 1>0
          print "test"
        loop
      Do-while:
        do
          print "test"
        loop while 1>0
      While-until:
        while 1>0
          print "test"
        loop until 1>0
      Any other combination of "while" and "until" is allowed.
  sub name(params), end sub
    Defines a subroutine. Example:
      sub double(x)
        return 2*x
      end sub
      print double(5)
  return
  return val
    Returns immediately from a subroutine, optionally returning a value.
    If no value is given, it returns void.
  break
    Jumps to the statement following the loop.
  continue
    Jumps to the beginning of the loop.

Functions:
  When calling a function, you must include parentheses even if the
  function doesn't take any arguments. If you don't the interpreter will
  treat the function as a variable.

  rnd()
    Returns a random number in the range [0,1)
  floor(x)
    Converts x to an integer, rounded down.
  ceil(x)
    Converts x to an integer, rounded up.
  round(x)
    Rounds x to the nearest integer.
  sleep(x)
    Sleeps for x seconds. Isn't very accurate for short intervals.
  swap(a,b)
    Swaps two variables.
  abs(x), exp(x), log(x), sign(x), sqrt(x), sin(x), cos(x), tan(x)
    Standard mathematical functions.
  len(x)
    Returns the length of x. x can be a string or an array.
  toupper(str), tolower(str)
    Convert a string to upper/lower case.
  left(str, n), right(str, n)
    Return n characters from the beginning or end of the string.
  mid(str, a, b)
    Returns b elements from the string, starting at index a.
  substring(str,a,b)
    Returns b-a elements from the string, starting at index a.
  isdigit(str)
    If the string has only 1 character, returns whether it's a digit.
    Otherwise, returns false.
  val(x)
    Converts x to a number.
  str(x)
    Converts x to a string.
  date(), time()
    Returns the current date and time.
  gettime(), gettime2(), starttimer(), stoptimer()
    These functions use a timer built into the interpreter.
    gettime() returns the time in seconds since the timer was started.
    gettime2() returns a human-readable string.
    The other functions start and stop the timer.
  openwindow(x,y) or openwindow(x,y,title)
    Open the graphical window. (x,y) is the size in pixels, and the title
    is optional.
  closewindow()
    Close the window.
  updatewindow()
    Update the window with everything that has been drawn since the last
    call to this function.
  draw(type), enddraw(), vertex(x,y)
    Draw a shape. Possible types:
      lines, points, polygon, linestrip, lineloop
    Example:
      draw(polygon)
      vertex(0,0)
      vertex(0,100)
      vertex(100,100)
      vertex(100,0)
      endDraw()
  color(r,g,b)
    Sets the red, green, and blue components of the on-screen color.
    Example:
      'sets the color to yellow
      color(1,1,0)
  pressed(key)
    key can be either a character or the string "esc", which is the escape
    key.
  rendertext(str,x,y,size)
    Prints text on the screen. Size 16 looks best. Other sizes can be
    used, but they make the text blurry.
  eval(str)
    Parses the string into BASIC code, and then evaluates it.
  exit()
    Exits the program. May print an error message when called from a
    graphical program.

Operators:
  -
    Negation or subtraction
  +, -, *, /, ^, mod
    standard arithmetic operations
  not
    Negates a boolean.
  >=, <=, <>, =, ==, <, >
    Comparison operations. = and == are equivalent. == is only provided
    because = is also used for assignment.
  and, or, xor, eqv, imp
    Logical operations
  parentheses
    Used to modify the standard precedence of the operators, and also
    to enclose function arguments.

Values:
  pi, e
    Mathematical constants.
  void
    Contains no information. The interpreter treats most statements and
    many functions as returning void.
  true, false
    True is equal to 1. False is equal to 0.
  _code
    The entire code of the currently executing BASIC program. It's
    useful for debugging, because it allows you to see how the interpreter
    parsed the BASIC code. If the interpreter failed to parse something
    but didn't give an error message, the _code variable will be
    truncated at the point where it failed to parse.
    If you print the value of the _code variable, it should result in
    valid BASIC code equivalent to the original BASIC code.
    You are not allowed to modify the _code variable. The interpreter
    uses it to know where to jump to when using control structures
    such as goto and loops. If you were allowed to modify it, your
    program would crash.
  _env
    The environment containing all variables that have been assigned.
    Useful for debugging.

    _env doesn't contain the _code variable, because that would make the
    output too long.

  You can't modify these built-in constants.


Unimplemented features:
  Integers
    Floating-point numbers are inaccurate when representing
    large integers, but it isn't normally a problem because it only
    happens with numbers larger than 10 quadrillion or so.

  Data structures
  Multidimensional arrays
  Function overloading
  More number formats (exponents, hexadecimal)
  Performance improvements

Bugs:
  When exit() is called within a callback, an error message is printed on the
  command line. It doesn't seem to happen when you call sleep(1) after
  updateWindow.

  Sometimes hanoi.bas triggers a segfault. I suspect that this is a bug in
  GLFW, Haskell's OpenGL API, or some other library.

  Bug in hanoi.bas - if you use a large number of rings and press 'c',
    you will get a stack overflow after a few minutes.
