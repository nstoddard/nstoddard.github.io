{-# LANGUAGE NoMonomorphismRestriction #-}

{- This is the parser. It converts a string into an expression that
can then be evaluated.-}

module Parse where

import Text.Parsec
import Text.Parsec.Expr
import Control.Monad
import Data.Char
import Debug.Trace
import Text.Printf
import Data.Maybe
import Data.List
import qualified Data.Map as M
import Network.CGI.Protocol (maybeRead)
import Data.IORef

--to put in util module:
roundTo :: Int -> Double -> String
roundTo n x = digits ++ reverse (dropWhile (`elem` "0.")
  (reverse (take (n+1) decimals)))
  where
    x' = printf ("%."++show n++"f") x :: String
    index' = elemIndex '.' x'
    index = if isJust index' then fromJust index' else length x'
    (digits,decimals) = splitAt index x'

mapWithIndex f = map f . zip [0..]

--All statements and expressions have this type.
data Expr =
  --"print", "input", etc.
  Opcode String [Expr] |
  --Operators (binary and unary)
  BinOp String Expr Expr | UnOp String Expr |
  --Assignment
  Let Bool Expr Expr | 
  --Data types
  Number Double | Str String | Void | Identifier String |
  --GOTOs
  Label String | JumpTo String |
  --Two types of if statments: single-line and multi-line
  If Expr Expr Expr | MultiIf Expr | Else | EndIf |
  --Loops
  For Expr Expr Expr Expr | Next | Do LoopType | Loop LoopType |
  --Specialized GOTOs within loops
  Break | Continue |
  --Punctuation (affects "print" statement)
  Comma | Semicolon |
  --Arrays
  Array Arr | ArrayAccess String Expr |
  --Subroutines
  Sub String [String] | EndSub |
  --Used for built-in subroutines and user-defined ones
  Call String [Expr] |
  --Immediately returns a value from a subroutine
  Return Expr |
  --Used for _code and _env variables
  ExprList [Expr] | Environment [(Bool,String,Expr)]
  deriving (Eq, Ord)

--This function defines how to display an expression
instance Show Expr where
  show (Opcode str []) = str
  show (Opcode str xs) = str ++ " " ++ unwords (map show xs)
  show (BinOp str a b) = "(" ++ show a ++ " " ++ str
    ++ " " ++ show b ++ ")"
  show (UnOp str a) = "(" ++ str ++ " " ++ show a ++ ")"
  show (Let False var val) = show var ++ " = " ++ show val
  show (Let True var val) = "global " ++ show var ++ " = " ++ show val
  show (Number n) = roundTo 4 n
  show (Str str) = show str
  show Void = "void"
  show (Identifier x) = x
  show (Label str) = str++":"
  show (JumpTo x) = "jumpTo " ++ x
  show (If cond true Void) = "if " ++ show cond ++ " then " ++
    show true
  show (If cond true false) = "if " ++ show cond ++ " then " ++
    show true ++ " else " ++ show false
  show (MultiIf cond) = "if " ++ show cond ++ " then "
  show Else = "else"
  show EndIf = "end if"
  show (For var start end step) = "for " ++ show var ++ " = " ++
    show start ++ " to " ++ show end ++ " step " ++ show step
  show Next = "next"
  show (Do Infinite) = "do"
  show (Do x) = show x
  show (Loop Infinite) = "loop"
  show (Loop x) = "loop " ++ show x
  show Break = "break"
  show Continue = "continue"
  show Comma = ","
  show Semicolon = ";"
  show (Array xs) = intercalate "; " $
    map (\(k,v)->show k ++ "," ++ show v) $ M.toList xs
  show (ArrayAccess str exp) = str ++ "[" ++ show exp ++ "]"
  show (Sub x args) = "sub " ++ x ++ commaParens args
  show EndSub = "end sub"
  show (Call fn args) = fn ++ commaParens (map show args)
  show (Return x) = "return " ++ show x
  show (ExprList xs) = unlines $ map show xs
    --This line prints line numbers as well, but the resulting code
    --won't parse correctly
    --mapWithIndex (\(i,x)->show (i+1) ++ ": " ++ show x) xs
  show (Environment env) = unlines $
    map (\(global,k,v) -> (if global then "global " else "") ++ k ++
    " = " ++ show v) env

data LoopType = Infinite | While Expr | Until Expr deriving (Eq, Ord)

--The environment is a list of all variables and their values.
type Env' = M.Map String Expr
type Env = Env'
type Arr = M.Map Int Expr

instance Show LoopType where
  show Infinite = "(infinite)"
  show (While x) = "while " ++ show x
  show (Until x) = "until " ++ show x

maybeToNum :: String -> Expr
maybeToNum x = if isJust x' then Number (fromJust x') else Str x
  where
    x' = maybeRead x_ :: Maybe Double
    x_ = if not (null x) && head x == '.' then '0':x else x

toNum (Number x) = return $ Number x
toNum (Str str) = return $ Number $ fromMaybe 0 (maybeRead str)
toNum x = do
  putStrLn $ "Incorrect parameters to toNum: " ++ show x
  return (Number 0)

--Like show, but intended for output from the print statement
show' (Str str) = str
show' Comma = "\t"
show' Semicolon = ""
show' x = show x

commaSep = intercalate ", "
commaParens xs = '(' : commaSep xs ++ ")"
quote x = '"' : x ++ "\""

opcodes = ["printdebug","print","?","inputglobal","input","goto",
  "run"]
--These opcodes evaluate their arguments
evalOpcodes = ["print","?"]

keywords = ["if","then","else","for","to","step","next","let","global",
  "'", "do","loop","while","until","sub","end","return","break",
  "continue"]

functions = ["rnd","floor","ceil","round","sleep","swap",
  "abs","exp","log","sign","sqrt","sin","cos","tan",
  "len","toupper","tolower","left","right","mid","substring","val","str",
  "date","time","gettime2","gettime","starttimer", "stoptimer",
  "openwindow","closewindow","updatewindow","draw","enddraw","vertex",
  "color", "pressed", "rendertext",
  "eval","exit", "isdigit",
  "graph"]
noEvalFunctions = ["swap"]
values = ["pi","e", "void", "true", "false",
  "lines","points","polygon","linestrip","lineloop","_code","_env"]

--This is the table of all operators and their precedence. The parsing
--library I'm using (Parsec) handles all the details.
--The operators are also listed in the list below this one
opTable = [
  [unop "-"],
  [unop "not"],
  [binopR "^"],
  [binop "*", binop "/", binop "mod"],
  [binop "+", binop "-"],
  [binop ">=", binop "<=", binop "<>", binop "!=", binop "==",
    binop "=", binop "<", binop ">"],
  [binop "and", binop "or", binop "xor", binop "eqv", binop "imp"]
  ]

operators = ["-","not","^","*","/","mod","+","-",
  ">=","<=","<>","!=","==","=","<",">","and","or","xor","eqv","imp"]

binary name fun = Infix
  (try $ lineSpaces >> stringIgnoreCase name >> return fun)
prefix name fun = Prefix
  (try $ lineSpaces >> stringIgnoreCase name >> return fun)
binop name = binary name (BinOp name) AssocLeft
binopR name = binary name (BinOp name) AssocRight
unop name = prefix name (UnOp name)

--All predefined, unmodifiable values.
everything = opcodes++keywords++functions++values++operators


a >>! b = do
  res <- a
  b
  return res

pconcat = foldr mplus mzero
pconcat2 = foldl mplus mzero
oneOf' = pconcat . map (try.string)
oneOfIgnoreCase = pconcat . map (try . stringIgnoreCase)
oneOfIgnoreCase_ = pconcat . map (try . charIgnoreCase)

charIgnoreCase x = char (toLower x) <|> char (toUpper x)

stringIgnoreCase [] = return []
stringIgnoreCase (x:xs) = do
  first <- try $ charIgnoreCase x
  rest <- stringIgnoreCase xs
  return (toLower first:rest)

parseID = do
  let fstCheck = letter <|> char '_'
  let restCheck = fstCheck <|> digit <|> char '$'
  fst <- fstCheck
  rest <- many restCheck
  let str = map toLower $ fst:rest
  if str `elem` ((everything\\functions)\\values)
    then mzero
    else return (Identifier str)

parseArgs = do
  args <- sepBy parseVal' (char ',')
  return args

parseLabel = do
  (Identifier str) <- parseID
  char ':'
  return (Label str)
  
parseOpcode = do
  str <- oneOfIgnoreCase opcodes
  args <- (lineSpaces1 >> many1 parseVal') <|> return []
  return (Opcode str args)

parseLExpr = try parseArrayAccess <|> parseID

parseArrayAccess = do
  (Identifier id) <- parseID
  lineSpaces >> char '['
  i <- parseVal'
  lineSpaces >> char ']'
  return $ ArrayAccess id i


parseLet = do
  optional $ stringIgnoreCase "let" >> lineSpaces1
  var <- parseLExpr
  lineSpaces >> string "="
  val <- parseVal'
  return $ Let False var val

parseGlobalLet = do
  stringIgnoreCase "global" >> lineSpaces1
  var <- parseLExpr
  lineSpaces >> string "="
  val <- parseVal'
  return $ Let True var val

parseStep = do
  lineSpaces >> stringIgnoreCase "step"
  lineSpaces >> parseVal' --todo: use lineSpaces1?

parseFor = do
  stringIgnoreCase "for"
  var <- lineSpaces1 >> parseID
  lineSpaces >> string "="
  start <- parseVal'
  lineSpaces1 >> stringIgnoreCase "to"
  end <- lineSpaces1 >> parseVal'
  step <- try parseStep <|> return (Number 1)

  return $ For var start end step

parseNext = do
  lineSpaces >> stringIgnoreCase "next"
  return Next

convertLoopType "" = return Infinite
convertLoopType "do" = return Infinite
convertLoopType "while" = do
  expr <- lineSpaces1 >> parseVal'
  return (While expr)
convertLoopType "until" = do
  expr <- lineSpaces1 >> parseVal'
  return (Until expr)

parseDo = do
  typ' <- oneOfIgnoreCase ["do","while","until"]
  typ <- convertLoopType typ'
  return (Do typ)

parseLoop = do
  stringIgnoreCase "loop"
  typ' <- (lineSpaces1 >> oneOfIgnoreCase ["while","until",""]) <|>
    return ""
  typ <- convertLoopType typ'
  return (Loop typ)

parseElse = do
  spaces' >> stringIgnoreCase "else"
  lineSpaces1 >> parseExpr

parseIf = do
  stringIgnoreCase "if"
  cond <- lineSpaces1 >> parseVal'
  spaces' >> stringIgnoreCase "then"
  act <- lineSpaces1 >> parseExpr
  act2 <- try parseElse <|> return Void
  optional $ parseNewline
  return $ If cond act act2


parseMultiIf = do
  stringIgnoreCase "if"
  cond <- lineSpaces1 >> parseVal'
  spaces' >> stringIgnoreCase "then"
  return (MultiIf cond)

parseMultiElse = do
  stringIgnoreCase "else"
  return Else

parseMultiEndIf = do
  stringIgnoreCase "end"
  lineSpaces1
  stringIgnoreCase "if"
  return EndIf

parseReturn = do
  stringIgnoreCase "return"
  val <- (lineSpaces1 >> parseVal') <|> return Void
  return $ Return val

parseBreak = do
  stringIgnoreCase "break"
  return Break

parseContinue = do
  stringIgnoreCase "continue"
  return Continue

parseSub = do
  stringIgnoreCase "sub"
  (Identifier id) <- lineSpaces1 >> parseID
  lineSpaces >> char '('
  args <- try (sepBy parseID (lineSpaces >>char ',' >> lineSpaces))
    <|> return []
  let args' = map (\(Identifier x)->x) args
  lineSpaces >> char ')'
  return $ Sub id args'

parseEndSub = do
  stringIgnoreCase "end"
  lineSpaces1 >> stringIgnoreCase "sub"
  return EndSub

parseCall = do
  (Identifier id) <- parseID
  lineSpaces >> char '('
  args <- try parseArgs <|> return []
  lineSpaces >> char ')'
  return $ Call id args

escapeChars = [('n','\n'), ('t','\t'), ('\\','\\'), ('0','\0'),
  ('b','\b'), ('r','\r'), ('"','"'), ('\'','\'')]
parseEscapeChar = do
  char '\\'
  x <- oneOfIgnoreCase_ (map fst escapeChars)
  return . fromJust $ lookup x escapeChars

parseString = do
  char '"'
  chars <- many (try parseEscapeChar <|> noneOf "\"")
  char '"'
  return (Str chars)

parseInt = do
  digits <- many1 digit
  return (Number $ read digits)
  
parseFloat = do
  digits' <- many digit
  let digits = if null digits' then "0" else digits'
  char '.'
  decimal <- many1 digit
  return (Number (read $ digits ++ "." ++ decimal))

parseNum = try parseFloat <|> parseInt

parseParens = do
  char '('
  res <- parseVal'
  lineSpaces >> char ')'
  return res

parseComma = char ',' >> return Comma
parseSemicolon = char ';' >> return Semicolon

--Parses a statement. The sub-parsers should not parse a newline.
parseStatement = pconcat2 . map f $ [
  (True,parseGlobalLet), (True,parseLet),
  (True,parseMultiIf), (True,parseMultiElse), (True,parseMultiEndIf),
  (False,parseIf),
  (True,parseFor), (True,parseNext),
  (True,parseSub), (True,parseEndSub), (True,parseReturn),
  (True,parseBreak), (True,parseContinue),
  (True,parseDo), (True,parseLoop),
  (True,parseOpcode),
  (True,parseLabel)]
  where
    f (True,x) = try (x >>! parseNewline)
    f (False,x) = try x

parseVal = lineSpaces >> (
  try parseCall <|>
  try parseArrayAccess <|>
  try parseParens <|>
  try parseString <|> try parseNum <|> try parseComma <|>
  try parseSemicolon <|> parseID)

parseLine = lineSpaces >>
  (liftM (:[]) parseStatement <|> parseLineValues <|>
  (parseNewline >> return []))
  >>! lineSpaces

parseNewline = lineSpaces >> (char '\n' <|> char ':') >> lineSpaces

parseVal' = lineSpaces >>
  buildExpressionParser opTable parseVal >>! lineSpaces

parseExpr = parseStatement <|> parseVal'

parseLineValues = do
  res <- many1 parseVal'
  parseNewline
  return res

parseComment = optional $ do
  char '\''
  skipMany (noneOf "\n")

lineSpaces = parseComment >> skipMany (oneOf " \t") >> parseComment
--This was intended to require at least one space, but it often
--resulted in parse errors where there shouldn't be any, so I disabled
--it.
lineSpaces1 = lineSpaces

--For debugging, I might want to redefine this to lineSpaces
--This used to call parseComment
spaces' = spaces
