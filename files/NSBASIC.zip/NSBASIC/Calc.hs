module Calc where

import Control.Monad
import Control.Applicative
import Control.Arrow hiding (loop)
import System.Exit
import Data.List
import Debug.Trace

import Graphics.Rendering.OpenGL
import Graphics.UI.GLFW

import ListExtra
import NumExtra
import OldGUI
import Vect

{- TODO:
  make derivative numerically stable
-}

--Calculates the derivative of a function at a point using an inaccurate
--method. If h is too big, the result will be inaccurate. If h is too
--small and x is large, the result will be very inaccurate, especially
--if a higher-order derivative is used.
derivative_ :: (Real a, Fractional a) => a -> (a -> a) -> a -> a
derivative_ h f x = (f (x+h) - f (x-h)) / (2*h)

derivative f x = derivative_ h f x
  where h = if x==0 then 1.0e-5 else x * 1.0e-3

--Calculates an integral. Uses the midpoint method. The first argument
--is the number of rectangles. Very accurate with high n, but slow.
integral_ :: (Real a, Fractional a) => Int -> (a -> a) -> a -> a -> a
integral_ n f x0 x1 = sum vals where
  dx = (x1-x0) / fromIntegral n
  vals = map ((*dx) . f . (+(dx/2))) $ take n $ iterate (+dx) x0

integral = integral_ 100

--Calculates the local maximums and minimums of a function. Doesn't work
--well because the derivative function is inaccurate.
minMax acc n f range@(x0,x1) = partition (\(x,_) -> derivative f x > 0) .
  map (id &&& f) . zeros acc n (derivative f) $ range
  where f' = derivative_ ((x1-x0) / fromIntegral n) f

--returns all values of x for which f(x) = 0
--the function must be continuous
--won't return zeros if they are a local min or max
zeros :: R -> Int -> (R -> R) -> (R, R) -> [R]
zeros acc n f (x0,x1) = {-traceShow (length close,length far) $ -}map (\((_,x),_) -> x) close ++
  concatMap (\((_,x0),(_,x1)) -> zeros acc n f (x0-dx,x1+dx)) far
  where
    dx = (x1-x0) / fromIntegral n
    xs = take n $ iterate (+dx) x0
    signs = map (signum . f) xs
    (close,far) = partition (\((_,x),_) -> abs (f x) < acc) $
      findDiffAdjacentWith fst $ zip signs xs

calcMain = do
  initDisplay (V2 900 900) "Calculator" False
  cacheCircle 64
  loop

--Graphs a function
graph_ :: R -> (R -> R) -> (R, R) -> (R, R) -> IO ()
graph_ diff f (xmin,xmax) (ymin,ymax) = do
  orthoV (V2 xmin ymin) (V2 xmax ymax)
  lineWidth $= 2

  let
    xpoints = map fromIntegral [ceiling xmin, ceiling xmin+1 .. floor xmax]
    ypoints = map fromIntegral [ceiling ymin, ceiling ymin+1 .. floor ymax]
    grid =
      concatMap (\x -> [V2 x ymin, V2 x ymax]) xpoints ++
      concatMap (\y -> [V2 xmin y, V2 xmax y]) ypoints
    {-xpoints' = zip [xmin..] $ delete 0 $ map (flip V2 0) xpoints
    ypoints' = zip [ymin..] $ delete 0 $ map (V2 0) ypoints
  forM_ xpoints' $ \(n,pos) -> renderText' grey pos (show n)
  forM_ ypoints' $ \(n,pos) -> renderText' grey pos (show n)-}

  color darkgrey
  renderPrimitive Lines $ mapM_ v grid

  color grey
  renderPrimitive Lines $ mapM_ v
    [V2 xmin 0, V2 xmax 0, V2 0 ymin, V2 0 ymax]

  color white
  let
    vals = filter (not . isNaN . snd) $
      map (id &&& f) [xmin, xmin+diff .. xmax]
  renderPrimitive LineStrip $ forM_ vals $ \(x,y) -> v (V2 x y)

--Graphs a polar function
graphPolar_ :: R -> (R -> R) -> (R, R) -> (R, R) -> (R, R) -> IO ()
graphPolar_ diff f (tmin, tmax) (xmin, xmax) (ymin, ymax) = do
  orthoV (V2 xmin ymin) (V2 xmax ymax)
  lineWidth $= 2

  let
    xr = (xmax - xmin)/2
    yr = (ymax - ymin)/2
    r = sqrt (xr^2 + yr^2)
  color darkgrey
  forM_ [0..r] $ \r -> drawCircle LineLoop r 0

  let dt = pi/12
  color (gscale 0.3)
  renderPrimitive Lines $ forM_ [tmin, tmin + dt .. tmax] $ \t ->
    v 0 >> v (fromPolar $ V2 r t)
  
  color white
  let
    vals = filter (not . isNaN . snd) $
      map (id &&& f) [tmin, tmin+diff .. tmax]
  renderPrimitive LineStrip $ forM_ vals $ \(t,r) -> do
    v (fromPolar $ V2 r t)

integral2 f = integral_ 10 f 0

graph = graph_ 0.01

graphPolar = graphPolar_ 0.01

loop = do
  quitKey <- getKey $ SpecialKey ESC
  when (quitKey == Press) $ terminate >> exitSuccess
  let f x = x^3 - 2*x^2 - 5

  --graph (derivative f) (-10,10) (-10,10)
  --print $ minMax 1.0e-10 100 f (-10,10)

  graphPolar (\x -> 1/x) (0, 2*pi) (-5,5) (-5,5)
  updateDisplay
  advanceTime (const $ pure ()) 0 30
  loop
