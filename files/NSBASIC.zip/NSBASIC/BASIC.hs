{-# LANGUAGE NoMonomorphismRestriction #-}

import Control.Monad
import System.Environment
import System.Exit
import qualified Data.Map as M
import Graphics.Rendering.OpenGL.Raw.ARB.Compatibility
import Graphics.Rendering.OpenGL.Raw.Core31
import Graphics.Rendering.OpenGL hiding (Return)
import Text.Parsec
import System.IO
import System.Directory
import Graphics.UI.GLFW hiding (openWindow,closeWindow)
import Data.Maybe
import System.Time
import Data.List
import Data.IORef
import System.Random
import Data.Char
import Data.Fixed (mod')
import System.IO.Unsafe
import Control.Concurrent (threadDelay)
import Control.Applicative hiding (many)

import Parse
import Graphics
import Calc

--to put in util module:
replaceAt :: Int -> a -> [a] -> [a]
replaceAt _ _ [] = error "replaceAt: index past end of list"
replaceAt 0 x (_:ys) = x:ys
replaceAt n x (y:ys) = y:replaceAt (n-1) x ys

a `nor` b = not a && not b

--like the Arrow first function, but monadic
firstM :: Monad m => (a->m a') -> (a,b) -> m (a',b)
firstM f (a,b) = do
  a' <- f a
  return (a',b)


globalEnv :: IORef Env
globalEnv = unsafePerformIO $ newIORef emptyGlobalEnv
globalProgram :: IORef [Expr]
globalProgram = unsafePerformIO $ newIORef undefined

globalTimer :: IORef Double
globalTimer = unsafePerformIO $ newIORef 0
globalStoppedTime :: IORef (Maybe Double)
globalStoppedTime = unsafePerformIO $ newIORef (Just 0)


shouldExit :: IORef Bool
shouldExit = unsafePerformIO $ newIORef False


padWithL n x xs = replicate (n-length xs) x ++ xs

formatTime_ sep fns = Str . intercalate sep .
  map (takeEnd 2 . padWithL 2 '0' . show) .
  applyAll fns

formatTime = formatTime_ ":" [ctHour,ctMin,ctSec]
formatTime' = formatTime_ ":" [ctMin,ctSec]
formatDate = formatTime_ "/" [succ.fromEnum.ctMonth,ctDay,ctYear]


mkBool b = Number $ if b then 1 else 0
fromBool = (/=0)
implies True False = False
implies _ _ = True
fromBool' (Number x) = fromBool x
fromBool' (Str x)
  | length x == 0 = False
  | head x == 'y' || head x == 'Y' = True
  | True = False
fromBool' _ = False

--This prevents the BASIC program from crashing by dividing by zero,
--instead returning either infinity or NaN
fmod 0 0 = 0/0
fmod n 0 = 1/0
fmod a b = mod' a b


--This evaluates an expression or statement
eval :: Expr -> Env -> IO (Expr,Env)
eval (Number n) env = return (Number n,env)
eval (Str str) env = return (Str str,env)
eval (Opcode x vals) env = do
  vals' <- if x `elem` evalOpcodes
    then mapM (liftM fst . flip eval env) vals
    else return vals
  evalOpcode (Opcode x vals') env
eval (BinOp x a b) env = do
  (a',_) <- eval a env
  (b',_) <- eval b env
  evalBinOp (BinOp x a' b') env
eval (UnOp x a) env = do
  (a',_) <- eval a env
  evalUnOp (UnOp x a') env
eval Void env = return (Void,env)
eval (Identifier x) env = do
  x' <- lookupID' (Number 0) x env
  return (x', env)
eval (Let global var val) env = do
  (val',_) <- eval val env
  case var of
    (Identifier str) -> if str `elem` everything
      then err env $ "You can't modify " ++ show str ++ "!"
      else addLet str val'
    (ArrayAccess str i') -> do
      i <- convertIndex i' env
      arr <- accessArray str env
      addLet str (Array $ M.insert (round i) val' arr)
  where
    addLet str val =
      if global
        then addGlobalEnv str val >> return (Void, env)
        else return (Void, addEnv str val env)
eval (Label _) env = return (Void,env)
eval (JumpTo _) _ = error "Can't eval JumpTo."
eval (If a t f) env = do
  (a',_) <- eval a env
  if fromBool' a' then eval t env else eval f env
eval (MultiIf cond) env = return (MultiIf cond, env)
eval Else env = return (Else, env)
eval EndIf env = return (EndIf, env)
eval Comma env = return (Comma, env)
eval Semicolon env = return (Semicolon, env)
eval (For (Identifier var) start end step) env = do
  (Number start',_) <- firstM toNum =<< eval start env
  (Number end',_) <- firstM toNum =<< eval end env
  (Number step',_) <- firstM toNum =<< eval step env
  let
    env' = addEnv var (Number start') env
  return (For (Identifier var) (Number start')
    (Number end') (Number step'), env')
eval (For {}) env = putStrLn "Incorrect arguments to for." >>
  return (Void,env)
eval Next env = return (Next,env)
eval (Do cond) env = return (Do cond, env)
eval (Loop cond) env = return (Loop cond, env)
eval (Sub x args) env = return (Sub x args, env)
eval EndSub env = return (Return Void, env)
eval (Return x) env = do
  (x',_) <- eval x env
  return (Return x', env)
eval Break env = return (Break,env)
eval Continue env = return (Continue,env)
eval (Call fn args) env = do
  if fn `elem` functions then do
    args' <- if fn `elem` noEvalFunctions
      then return args
      else liftM (map fst) $ mapM (flip eval env) args
    evalFn fn args' env
  else do
  args' <- mapM (liftM fst . flip eval env) args

  vals_ <- lookupID' (ExprList [Str "_code is missing!"]) "_code" env
  vals <- case vals_ of
    ExprList x -> return x
    _ -> err2 [] $ "You appear to have destroyed the _code variable. " ++
      "Please don't do that."
  i_ <- findSub 0 fn vals
  if isNothing i_ then return (Void,env) else do
  let i = fromJust i_
  i' <- liftM succ $ lookupEndSub vals (i+1) 1

  let (Sub _ argNames) = vals!!i
  let env' = M.union (M.fromList (zip argNames args')) env
  (result,env'') <- evalProgram (take (i'-i-2) $ drop (i+1) vals) env' 0
  return (result,env)
eval (Array {}) _ = error "Can't evaluate an array!"
eval (ArrayAccess id i') env = do
  i <- convertIndex i' env
  arr <- accessArray id env
  val <- lookupIDArr (Number 0) (round i) arr
  return (val,env)

incFor (For (Identifier var) _ _ step) env = do
  (Number step',_) <- firstM toNum =<< eval step env
  Number val <- lookupID' (error "For variable not found") var env
  pure $ addEnv var (Number $ val + step') env

accessArray id env = do
  val <- lookupID' (Array M.empty) id env
  return $ if isArray val
    then getArray val
    else M.empty
  where
    isArray (Array {}) = True
    isArray _ = False
    getArray (Array arr) = arr

convertIndex i env = do
  (i',_) <- eval i env
  --putStr $ show ("Converting",i')
  (Number i'') <- toNum i'
  return i''

lookupID = M.findWithDefault

lookupID' _ "_env" env = do
  global <- get globalEnv
  let
    env' = (map (\(k,v)->(True,k,v)) $ M.toList global) ++
      (map (\(k,v)->(False,k,v)) $ M.toList $ M.delete "_code" env)
  return $ Environment env'
lookupID' def x env = do
  env' <- liftM (M.union env) (get globalEnv)
  return $ lookupID def x env'

--TODO: remove (this is redundant)
lookupIDArr def x env = return $ lookupID def x env

addEnv = M.insert
deleteEnv = M.delete

addGlobalEnv key val = globalEnv $~ (M.insert key val)

applyAll f = (f<*>) . (:[])

takeEnd n = reverse . take n . reverse

mLength m = higher-lower+1 where
  keys = sort $ M.keys m
  higher = last keys
  lower = head keys

evalFn "rnd" [] env = do
  rnd <- randomIO
  return (Number rnd, env)
evalFn "floor" [Number x] env =
  return (Number (fromIntegral $ floor x), env)
evalFn "ceil" [Number x] env =
  return (Number (fromIntegral $ ceiling x), env)
evalFn "round" [Number x] env =
  return (Number (fromIntegral $ round x), env)
evalFn "abs" [Number x] env = return (Number (abs x), env)
evalFn "exp" [Number x] env = return (Number (exp x), env)
evalFn "log" [Number x] env = return (Number (log x), env)
evalFn "sign" [Number x] env = return (Number (signum x), env)
evalFn "sqrt" [Number x] env = return (Number (sqrt x), env)
evalFn "sleep" [Number x] env = do
  unless (x'<=0) $ threadDelay x'
  return (Void,env)
  where x' = floor $ x*1000000
evalFn "len" [Str str] env =
  return (Number (fromIntegral $ length str), env)
evalFn "len" [Array arr] env =
  return (Number (fromIntegral $ mLength arr), env)
evalFn "substring" [Str str, Number a, Number b] env =
  return (Str (take (round $ b-a) $ drop (round a) str), env)
evalFn "mid" [Str str, Number a, Number b] env =
  return (Str (take (round b) $ drop (round a) str), env)
evalFn "left" [Str str, Number n] env =
  return (Str (take (round n) str), env)
evalFn "right" [Str str, Number n] env =
  return (Str (reverse $ take (round n) $ reverse str), env)
evalFn "toupper" [Str str] env = return (Str (map toUpper str), env)
evalFn "tolower" [Str str] env = return (Str (map toLower str), env)
evalFn "isdigit" [Str [c]] env = return (mkBool (isDigit c), env)
evalFn "isdigit" [Str _] env = return (mkBool False, env)
evalFn "val" [x] env = do
  x' <- toNum x
  return (x', env)
evalFn "str" [x] env = return (Str (show x), env)
evalFn "swap" [a@(Identifier a'), b@(Identifier b')] env = do
  (av,_) <- eval a env
  (bv,_) <- eval b env
  return (Void, addEnv a' bv $ addEnv b' av $ env)
evalFn "swap" [ArrayAccess as a', ArrayAccess bs b'] env = do
  a'' <- convertIndex a' env
  a_ <- accessArray as env
  aval <- lookupIDArr (Number 0) (round a'') a_

  b''' <- convertIndex b' env
  b_' <- accessArray bs env
  bval' <- lookupIDArr (Number 0) (round b''') b_'

  let env' = addEnv as (Array $ M.insert (round a'') bval' a_) env

  b'' <- convertIndex b' env'
  b_ <- accessArray bs env'

  return (Void,addEnv bs (Array $ M.insert (round b'') aval b_) $ env')
evalFn "sin" [Number a] env = return (Number $ sin a, env)
evalFn "cos" [Number a] env = return (Number $ cos a, env)
evalFn "tan" [Number a] env = return (Number $ tan a, env)
evalFn "date" [] env = do
  time <- toCalendarTime =<< getClockTime
  return (formatDate time, env)
evalFn "time" [] env = do
  time <- toCalendarTime =<< getClockTime
  return (formatTime time, env)
evalFn "gettime" [] env = do
  (TOD seconds pico) <- getClockTime
  stoppedTime <- get globalStoppedTime
  if isJust stoppedTime then return (Number $ fromJust stoppedTime, env)
  else do
  oldTime <- get globalTimer
  let newTime = fromIntegral seconds + fromIntegral pico*1.0e-12 - oldTime
  return (Number newTime, env)
evalFn "gettime2" [] env = do
  (Number time, _) <- evalFn "gettime" [] env
  time' <- toCalendarTime (TOD (floor time) 0)
  return (formatTime' time', env)
evalFn "starttimer" [] env = do
  (TOD seconds pico) <- getClockTime
  globalTimer $= fromIntegral seconds + fromIntegral pico*1.0e-12
  globalStoppedTime $= Nothing
  return (Void, env)
evalFn "stoptimer" [] env = do
  (Number time, _) <- evalFn "gettime" [] env
  globalStoppedTime $= Just time
  return (Void, env)
evalFn "openwindow" [Number x,Number y] env = do
  openWindow "" (round x) (round y)
  keyCallback $= handleKey
  return (Void,env)
evalFn "openwindow" [Number x,Number y, Str title] env = do
  openWindow title (round x) (round y)
  keyCallback $= handleKey
  return (Void,env)
evalFn "closewindow" [] env = closeWindow >> return (Void,env)
evalFn "updatewindow" [] env = updateWindow >> return (Void,env)
evalFn "draw" [Number shape] env = glBegin (round shape) >>
  return (Void,env)
evalFn "enddraw" [] env = glEnd >> return (Void,env)
evalFn "vertex" [Number x, Number y] env =
  vertex (Vertex2 x y) >> return (Void, env)
evalFn "color" [Number r, Number g, Number b] env =
  color (Color3 r g b) >> return (Void, env)
evalFn "pressed" [Str str] env = f (map toLower str) where
  f str
    | str == "esc" = do
      pressed <- getKey (SpecialKey ESC)
      return (mkBool (pressed==Press), env)
    | length str == 1 = do
      pressed <- getKey (CharKey $ head str)
      return (mkBool (pressed==Press), env)
    | True = err env $ "Unknown key: " ++ str
evalFn "rendertext" [Str str, Number x, Number y, Number size] env =
  renderText str (x, y) size >> return (Void, env)
evalFn "eval" [Str str] env = evalProgram' str env ""
evalFn "exit" [] env = shouldExit $= True >> return (Void, env)

evalFn "graph" [] _ = calcMain

evalFn fn _ env = do
  if fn `elem` functions
    then putStrLn $ "The function " ++ show fn ++
      " has incorrect parameters."
    else putStrLn $ "The function " ++ show fn ++
      " doesn't exist."
  return (Void,env)

evalOpcode :: Expr -> Env -> IO (Expr,Env)
evalOpcode (Opcode "printdebug" vals) env = do
  mapM print vals
  return (Void,env)
evalOpcode (Opcode "print" vals) env = do
  mapM (putStr.show') vals
  if null vals then putStrLn "" else case last vals of
    Semicolon -> hFlush stdout
    Comma -> putStr "\t" >> hFlush stdout
    _ -> putStrLn ""
  return (Void,env)
evalOpcode (Opcode "?" x) env = evalOpcode (Opcode "print" x) env

evalOpcode (Opcode "input" [Str str,Identifier var]) env = do
  putStr str
  hFlush stdout
  val <- liftM maybeToNum getLine
  return (Void,addEnv var val env)
evalOpcode (Opcode "input" [Str str,ArrayAccess var i']) env = do
  putStr str
  hFlush stdout
  val <- liftM maybeToNum getLine
  i <- convertIndex i' env
  arr <- accessArray var env
  return (Void,addEnv var (Array $ M.insert (round i) val arr) env)
evalOpcode (Opcode "input" [Str str,Comma,x]) env =
  evalOpcode (Opcode "input" [Str str,x]) env
evalOpcode (Opcode "input" [x]) env =
  evalOpcode (Opcode "input" [Str "",x]) env

evalOpcode (Opcode "inputglobal" [Str str,Identifier var]) env = do
  putStr str
  hFlush stdout
  val <- liftM maybeToNum getLine
  addGlobalEnv var val
  return (Void,env)
evalOpcode (Opcode "inputglobal" [Str str,ArrayAccess var i']) env = do
  putStr str
  hFlush stdout
  val <- liftM maybeToNum getLine
  i <- convertIndex i' env
  arr <- accessArray var env
  addGlobalEnv var (Array $ M.insert (round i) val arr)
  return (Void,env)
evalOpcode (Opcode "inputglobal" [Str str,Comma,x]) env =
  evalOpcode (Opcode "inputglobal" [Str str,x]) env
evalOpcode (Opcode "inputglobal" [x]) env =
  evalOpcode (Opcode "inputglobal" [Str "",x]) env

evalOpcode (Opcode "goto" [Identifier x]) env =
  return (JumpTo x, env)
evalOpcode (Opcode "run" [Str file]) env =
  runFile env file
evalOpcode (Opcode "run" [Identifier file]) env =
  runFile env file
evalOpcode (Opcode x _) env = do
  if x `elem` opcodes
    then putStrLn $ "Opcode " ++ show x ++ " has incorrect parameters."
    else putStrLn $ "Opcode " ++ show x ++ " does not exist."
  return (Void,env)
evalOpcode _ _ = error "evalOpcode called without an opcode!"

runFile :: Env -> FilePath -> IO (Expr,Env)
runFile env file = do
  let file' = file ++ ".bas"
  exists <- doesFileExist file
  exists' <- doesFileExist file'
  if exists&&exists' then err env $ "Can't decide whether to run "
    ++ file ++ " or " ++ file' ++ "!" else do
  if exists `nor` exists' then err env $ "Can't find " ++ file ++
    " or " ++ file ++ ".bas" else do
  (_,env') <- if exists then runFile' env file
    else return (undefined,env)
  (_,env'') <- if exists' then runFile' env' file'
    else return (undefined,env')
  return (Void,env'')

  where
    runFile' env filename = do
      input <- readFile filename
      evalProgram' input env filename

evalProgram' input env filename = do
  case parse (many parseLine) filename input of
    Left err -> putStrLn ("Parse error: " ++ show err) >>
      return (Void,env)
    Right vals' -> let vals = concat vals' in do
      globalProgram $= vals
      evalProgram vals (appendExprList "_code" (ExprList vals) env) 0
  

err env msg = putStrLn msg >> return (Void,env)
err2 x msg = putStrLn msg >> return x

evalBinOp :: Expr -> Env -> IO (Expr,Env)
evalBinOp (BinOp "+" (Number a) (Number b)) env =
  return (Number (a+b), env)
evalBinOp (BinOp "+" (Str a) (Str b)) env =
  return (Str (a++b), env)
evalBinOp (BinOp "-" (Number a) (Number b)) env =
  return (Number (a-b), env)
evalBinOp (BinOp "*" (Number a) (Number b)) env =
  return (Number (a*b), env)
evalBinOp (BinOp "*" (Str a) (Number b)) env = 
  return (Str . concat $ replicate (round b) a, env)
evalBinOp (BinOp "*" (Number a) (Str b)) env =
  evalBinOp (BinOp "*" (Str b) (Number a)) env
evalBinOp (BinOp "^" (Number a) (Number b)) env =
  return (Number (a**b), env)
evalBinOp (BinOp "/" (Number a) (Number b)) env =
  return (Number (a/b), env)
evalBinOp (BinOp "mod" (Number a) (Number b)) env =
  return (Number (a`fmod`b), env)
evalBinOp (BinOp "=" a b) env =
  return (mkBool (a==b), env)
evalBinOp (BinOp "==" a b) env =
  return (mkBool (a==b), env)
evalBinOp (BinOp "<>" a b) env =
  return (mkBool (a/=b), env)
evalBinOp (BinOp "!=" a b) env = evalBinOp (BinOp "<>" a b) env
evalBinOp (BinOp "<" a b) env =
  return (mkBool (a<b), env)
evalBinOp (BinOp ">" a b) env =
  return (mkBool (a>b), env)
evalBinOp (BinOp "<=" a b) env =
  return (mkBool (a<=b), env)
evalBinOp (BinOp ">=" a b) env =
  return (mkBool (a>=b), env)

evalBinOp (BinOp "and" (Number a) (Number b)) env =
  return (mkBool (fromBool a&&fromBool b), env)
evalBinOp (BinOp "or" (Number a) (Number b)) env =
  return (mkBool (fromBool a||fromBool b), env)
evalBinOp (BinOp "xor" (Number a) (Number b)) env =
  return (mkBool (fromBool a/=fromBool b), env)
evalBinOp (BinOp "eqv" (Number a) (Number b)) env =
  return (mkBool (fromBool a==fromBool b), env)
evalBinOp (BinOp "imp" (Number a) (Number b)) env =
  return (mkBool (fromBool a`implies`fromBool b), env)
evalBinOp (BinOp name _ _) env = err env $ "The operator " ++ show name ++
  " has incorrect parameters."
evalBinOp _ _ = error "evalBinOp called without a binary operator!"

evalUnOp (UnOp "not" (Number a)) env =
  return (mkBool (not (fromBool a)), env)
evalUnOp (UnOp "-" (Number a)) env =
  return (Number (-a), env)
evalUnOp (UnOp name _) env = err env $ "The operator " ++ show name ++
  " has incorrect parameters."
evalUnOp _ _ = error "evalUnOp called without an unary operator!"

--This is the "Read-eval-print loop". It reads an expression, evaluates
--it, and prints the result out.
repl :: Env -> IO ()
repl env = do
  putStr "> "
  hFlush stdout
  input <- getLine
  if input `elem` [""]
    then exitWith' ExitSuccess
    else do
      env' <- case parse (many1 parseLine) "" (input++"\n") of
        Left err -> putStrLn ("Parse error: " ++ show err) >> return env
        Right vals' -> let vals = concat vals' in foldM (\env val -> do
          (val,env') <- eval val env
          when (val/=Void) $ print val
          maybeExit
          return env') env vals
      repl env'

appendExprList str (ExprList vals) env =
  M.adjust (\(ExprList vals')->ExprList (vals++vals')) str env

lookupLabel :: String -> [Expr] -> Int -> IO Int
lookupLabel lbl [] i = putStrLn ("Label not found: " ++ lbl)
  >> return i
lookupLabel lbl (Label lbl':xs) i
  | lbl == lbl' = return i
  | True = lookupLabel lbl xs (i+1)
lookupLabel lbl (_:xs) i = lookupLabel lbl xs (i+1)

inRange i xs = i >= 0 && i < length xs
outOfRange i = not . inRange i

--These lookup functions handle nesting of loops properly
--(They are somewhat inefficient and redundant)
lookupFor _ i 0 = return (i+1)
lookupFor vals i n
  | outOfRange i vals = err2 (length vals)
    "Unable to find matching FOR statement."
  | True = case vals!!i of
  (For {}) -> lookupFor vals (i-1) (n-1)
  Next -> lookupFor vals (i-1) (n+1)
  _ -> lookupFor vals (i-1) n

lookupNext _ i 0 = return i
lookupNext vals i n
  | outOfRange i vals = err2 (length vals)
    "Unable to find matching NEXT statement."
  | True = case vals!!i of
  (For {}) -> lookupNext vals (i+1) (n+1)
  Next -> lookupNext vals (i+1) (n-1)
  _ -> lookupNext vals (i+1) n

lookupEndIf _ i 0 = return i
lookupEndIf vals i n
  | outOfRange i vals = err2 (length vals)
    "Unable to find matching END IF statement."
  | True = case vals!!i of
  (MultiIf {}) -> lookupEndIf vals (i+1) (n+1)
  Else -> lookupEndIf vals (i+1) (n-1)
  EndIf -> lookupEndIf vals (i+1) (n-1)
  _ -> lookupEndIf vals (i+1) n

lookupDo _ i 0 = return (i+1)
lookupDo vals i n
  | outOfRange i vals = err2 (length vals)
    "Unable to find matching DO statement."
  | True = case vals!!i of
  (Do {}) -> lookupDo vals (i-1) (n-1)
  (Loop {}) -> lookupDo vals (i-1) (n+1)
  _ -> lookupDo vals (i-1) n

lookupLoop _ i 0 = return i
lookupLoop vals i n
  | outOfRange i vals = err2 (length vals)
    "Unable to find matching LOOP statement."
  | True = case vals!!i of
  (Do {}) -> lookupLoop vals (i+1) (n+1)
  (Loop {}) -> lookupLoop vals (i+1) (n-1)
  _ -> lookupLoop vals (i+1) n

lookupStartLoop _ i 0 = return (i+1)
lookupStartLoop vals i n
  | outOfRange i vals = err2 (length vals)
    "Unable to find matching start of loop."
  | True = case vals!!i of
  (Do {}) -> lookupStartLoop vals (i-1) (n-1)
  (For {}) -> lookupStartLoop vals (i-1) (n-1)
  (Loop {}) -> lookupStartLoop vals (i-1) (n+1)
  (Next {}) -> lookupStartLoop vals (i-1) (n+1)
  _ -> lookupStartLoop vals (i-1) n

lookupEndLoop _ i 0 = return i
lookupEndLoop vals i n
  | outOfRange i vals = err2 (length vals)
    "Unable to find matching end of loop."
  | True = case vals!!i of
  (Do {}) -> lookupEndLoop vals (i+1) (n+1)
  (For {}) -> lookupEndLoop vals (i+1) (n+1)
  (Loop {}) -> lookupEndLoop vals (i+1) (n-1)
  (Next {}) -> lookupEndLoop vals (i+1) (n-1)
  _ -> lookupEndLoop vals (i+1) n

lookupEndSub _ i 0 = return i
lookupEndSub vals i n
  | outOfRange i vals = err2 (length vals)
    "Unable to find matching END SUB statement."
  | True = case vals!!i of
  (Sub {}) -> lookupEndSub vals (i+1) (n+1)
  (EndSub {}) -> lookupEndSub vals (i+1) (n-1)
  _ -> lookupEndSub vals (i+1) n

checkCond Infinite _ = return True
checkCond (While x) env = do
  (res,_) <- eval x env
  return $ fromBool' res
checkCond (Until x) env = do
  (res,_) <- eval x env
  return $ not $ fromBool' res

findSub _ str [] = putStrLn ("Subroutine " ++ show str ++ " not found.") >>
  return Nothing
findSub i str (Sub str' _:xs)
  | str==str' = return $ Just i
  | True = findSub (i+1) str xs
findSub i str (_:xs) = findSub (i+1) str xs

--TODO: this doesn't work; it is supposed to prevent an error when
--calling exit()
maybeExit = do
  exit <- get shouldExit
  callback <- get inCallback
  --when exit $ print (exit, callback)
  when (exit && not callback) $ exitWith' ExitSuccess

evalProgram vals env i
  | i == length vals = return (Void,env)
  | True = do
    --print vals
    (val',env') <- eval (vals!!i) env
    maybeExit
    (jumpTarget,env'') <- case val' of
      Void -> return (i+1, env')
      Return _ -> return (error "Returning undefined",env')
      JumpTo x -> do
        lbl <- lookupLabel x vals 0
        return (lbl,env')
      For {} -> return (i+1, env')
      Next -> do
        i' <- lookupFor vals (i-1) 1
        let for@(For (Identifier var) _ end_ step_) = vals !! i'
        env'' <- incFor for env'

        (Number end,_) <- firstM toNum =<< eval end_ env''
        (Number step,_) <- firstM toNum =<< eval step_ env''

        Number val <- lookupID' (error "Can't find var in for loop")
          var env''
        let done = (step>0 && val>end) || (step<0 && val<end)
        if done
          then do
            i'' <- lookupNext vals (i'+1) 1
            return (i'', env'')
          else return (i'+1, env'')
      MultiIf cond -> do
        (cond',_) <- eval cond env'
        if fromBool' cond' then return (i+1,env') else do
          i' <- lookupEndIf vals (i+1) 1
          return (i', env')
      Else -> do
        i' <- lookupEndIf vals (i+1) 1
        return (i', env')
      EndIf -> return (i+1, env')
      Do cond -> do
        loop <- checkCond cond env'
        if loop
          then return (i+1,env')
          else do
            i' <- lookupLoop vals (i+1) 1
            return (i', env')
      Loop cond -> do
        loop <- checkCond cond env'
        if loop
          then do
            i' <- lookupDo vals (i-1) 1
            return (i', env')
          else return (i+1,env')
      Break -> do
        i' <- lookupEndLoop vals (i+1) 1
        return (i', env')
      Continue -> do
        i' <- lookupStartLoop vals (i-1) 1
        return (i', env')
      Sub _ _ -> do
        i' <- lookupEndSub vals (i+1) 1
        return (i', env')
      x -> print x >> return (i+1, env')
    case val' of
      Return x -> return (x,env')
      _ -> evalProgram vals env'' jumpTarget

emptyGlobalEnv =
  addEnv "pi" (Number pi) $
  addEnv "e" (Number $ exp 1) $
  addEnv "void" Void $
  addEnv "true" (mkBool True) $
  addEnv "false" (mkBool False) $
  addEnv "lines" (Number $ fromIntegral gl_LINES) $
  addEnv "points" (Number $ fromIntegral gl_POINTS) $
  addEnv "polygon" (Number $ fromIntegral gl_POLYGON) $
  addEnv "linestrip" (Number $ fromIntegral gl_LINE_STRIP) $
  addEnv "lineloop" (Number $ fromIntegral gl_LINE_LOOP) $
  M.empty

emptyEnv =
  addEnv "_code" (ExprList []) $
  M.empty

main = do
  args <- getArgs
  let env = emptyEnv
  when (not $ null args) $ do
    foldM ((liftM snd .) . runFile) env args
    exitWith' ExitSuccess
  putStrLn "Welcome to Nathan Stoddard's BASIC interpreter."
  putStrLn "Read README.txt for documentation."
  putStrLn "Please enter an expression to evaluate:"
  repl env

convertKey (CharKey key) = [key]
convertKey (SpecialKey ESC) = "ESC"
convertKey (SpecialKey ENTER) = "\n"
convertKey (SpecialKey BACKSPACE) = "BACKSPACE"
convertKey _ = "unknown key"

handleKey key Press = do
  inCallback $= True
  program <- get globalProgram
  let program' = (program ++ [Call "handlekey" [Str $ convertKey key]])
  env <- return M.empty
  evalProgram program'
    (addEnv "_code" (ExprList program') env) (length program'-1)
  return ()
  inCallback $= False
handleKey _ _ = return ()
