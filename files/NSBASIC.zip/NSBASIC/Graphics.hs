{-# LANGUAGE NoMonomorphismRestriction #-}

module Graphics where

import qualified Graphics.UI.GLFW as GLFW
import Graphics.UI.GLFW hiding (windowSize, closeWindow)
import Graphics.Rendering.OpenGL as GL
import Data.List
import Control.Monad
import Graphics.Rendering.OpenGL.Raw.ARB.Compatibility
import Graphics.Rendering.OpenGL.Raw.Core31
import System.IO.Unsafe
import Data.IORef
import System.Exit

inCallback :: IORef Bool
inCallback = unsafePerformIO $ newIORef False

type GLR = GL.GLdouble

windowSize = unsafePerformIO (newIORef undefined)
windowOpen = unsafePerformIO (newIORef False)

openWindow title xs ys = do
  windowSize $= (xs,ys)
  initialize
  GLFW.openWindow (Size xs ys) [] Window
  windowTitle $= title
  blend $= Enabled
  blendFunc $= (SrcAlpha, OneMinusSrcAlpha)
  clear [ColorBuffer]
  loadIdentity
  ortho2D 0 (fromIntegral xs) (fromIntegral ys) 0
  windowOpen $= True

closeWindow = do
  open <- get windowOpen
  when open $ GLFW.closeWindow >> terminate
  windowOpen $= False

exitWith' x = closeWindow >> exitWith x

vertex' x y = vertex (Vertex2 (x::GLR) (y::GLR))

updateWindow = do
  (xs,ys) <- get windowSize

  swapBuffers

  clear [ColorBuffer]
  loadIdentity
  ortho2D 0 (fromIntegral xs) (fromIntegral ys) 0

renderText :: String -> (GLR,GLR) -> GLR -> IO ()
--renderText' is called twice because otherwise the text is too blurry
--(It's not an ideal solution, but I can't install the SDL libraries
--here at school).
renderText str pos size = replicateM_ 2 (renderText' str pos size)

renderText' str (dx,dy) size = do
  color (Color3 (10::GLR) 10 10)
  (xs,ys) <- get windowSize
  preservingMatrix $ do
  translate (Vector3 dx dy 0)
  scale (1::GLR) (-1) 1
  translate (Vector3 (0::GLR) (ys-size) 0)
  scale (size/16) (size/16) 1
  renderString Fixed8x16 str
