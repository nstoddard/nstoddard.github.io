Gravity 0.1 by Nathan Stoddard

This is a 2D planet simulator. You can place planets and watch them orbit each other. You can delete planets as well, and change a few characteristics of the simulation.

It's similar to the program "planets" (http://planets.homedns.org/).

Controls:
  Left click: place planet
    Up/down arrow keys: change size
    Left/right arrow keys: change color
    Left click again: finalize placement
    Right click: cancel
  Right click: delete closest planet to mouse cursor
    It only deletes when you release the mouse button; if you decide you don't want to delete anything after all, move the cursor away from everything
  Escape: quit
  Left/right/up/down: move the view
  Plus/minus: zoom in and out
  P: pause
  C: clear planets
  R: recenter on center of mass (subtracts the average velocity from each planet's velocity)
  Space: do a single step (only useful when paused)
  V: save
  L: load
  Comma/period: change the speed of the simulation
    Without shift pressed: change the number of steps per frame (higher = faster simulation, but slower)
    With shift pressed: change the timestep (higher = faster simulation, but less physically accurate and the simulation explodes at high timesteps)

  WASD can be used as an alternative to the arrow keys

Savefiles:
  Savefiles are stored in a plain text format that's easy to edit. By modifying them, you can change a few settings that you can't change in-game yet, such as the gravitational constant and exponent.
  There's some example savefile in the saves/ directory

Contact:
  Feel free to contact me at nstodda@purdue.edu with comments, suggestions, bug reports, etc
