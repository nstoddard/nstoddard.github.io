Welcome to Rebel Forever! The goal of the game is simple: to survive as long as possible. You'll encounter hundreds of enemy ships, all of which are randomly generated. Most ships will ignore you until you attack them, but not all of them! Occasionally, pirate ships will head straight for you and immediately attempt to kill you.

There are dozens of module types. Many of them are girders, which do nothing but increase the size of your ship and provide more places to attach modules. There are several weapon types, a few types of thrusters, and several other modules.

The controls are listed on the 'help' menu in-game. 

Files:
  bin/ - files needed to run the game
  licenses/ - licenses for assets used in the game
  README.txt - this file
  RebelForever.jar - the launcher; open this to run the game
  log.txt - this file is generated if an error occurs

Author:
  Nathan Stoddard (nstodda@purdue.edu)
  Feel free to send feedback to me at the above address. I appreciate feature requests, bug reports, and any other feedback.

Known bugs:
  Under some circumstances, your command module can shoot at another module on your own ship.
  Sometimes shields aren't charged when loading a saved game.
  Lasers sometimes shoot through the nearest module.
  Shields have several problems.
  On some systems, module borders are all white. I don't know how to fix this, unfortunately.
  When shooting a large group of modules, some of them can be thrown off at large velocities.
  Sometimes enemy ships spawn on top of one another.
  If the game window is too small, sometimes the help menu doesn't all fit on the screen and there's no way to scroll.
