ghc --make Hex -O -odir obj -hidir obj
