This is an implementation of the Hex board game that I wrote during an independent study in my senior year of high school. It was used for a class-wide competition in one of my teacher's classes.
