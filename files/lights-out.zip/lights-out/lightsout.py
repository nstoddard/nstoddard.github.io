#!/usr/bin/python

"""An implementation of the lights out game by Nathan Stoddard (nstodda@purdue.edu)."""
import pygame
from pygame.locals import *
from random import *
tile_size = 64
board_size = 3#int(raw_input("Enter size: "))
pygame.init()
pygame.display.set_caption("Lights out")
screen = pygame.display.set_mode((tile_size * board_size, tile_size * board_size))
board_range = range(0, board_size*board_size)
board_colors = [(0, 0, 0), (255, 255, 0)]
board = [randrange(0, len(board_colors)) for i in board_range]

def display_board():
  for i in board_range:
    pygame.draw.rect(screen, board_colors[board[i]],
      (i / board_size * tile_size, i % board_size * tile_size, tile_size, tile_size))
  pygame.display.update()

def in_range(pos):
  return pos[0] >= 0 and pos[1] >= 0 and pos[0] < board_size and pos[1] < board_size

def calc_pos(pos):
  return pos[0] * board_size + pos[1]

def toggle_tile(pos):
  for pos2 in [pos, (pos[0], pos[1] + 1), (pos[0], pos[1] - 1), (pos[0] + 1, pos[1]), (pos[0] - 1, pos[1])]:
    if in_range(pos2):
      board[calc_pos(pos2)] = 1 - board[calc_pos(pos2)]

display_board()
while True:
  event = pygame.event.wait()
  if event.type == QUIT:
    exit(0)
  elif event.type == MOUSEBUTTONDOWN:
    toggle_tile([e / tile_size for e in event.pos])
    display_board()
  elif event.type == KEYDOWN:
    exit(0)
