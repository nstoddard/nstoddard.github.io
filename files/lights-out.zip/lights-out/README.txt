This is an implementation of the Lights Out game (see
http://en.wikipedia.org/wiki/Lights_Out_(game)). When you click on a
light, it and all adjacent lights are toggled. The goal is to turn off
all the lights.

Author: Nathan Stoddard (nstodda@purdue.edu)
